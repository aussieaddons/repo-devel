# script.module.customsession
Custom Requests Session module for Aussie Addons
